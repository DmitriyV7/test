package day_4;
/*
    Data Types in Java
    8 primitive data types:
    byte	1 byte	Stores whole numbers from -128 to 127
    short	2 bytes	Stores whole numbers from -32,768 to 32,767
    int	    4 bytes	Stores whole numbers from -2,147,483,648 to 2,147,483,647
    long	8 bytes	Stores whole numbers from -9,223,372,036,854,775,808 to 9,223,372,036,854,775,807
    float	4 bytes	Stores fractional numbers. Sufficient for storing 6 to 7 decimal digits
    double	8 bytes	Stores fractional numbers. Sufficient for storing 15 decimal digits
    boolean	1 bit	Stores true or false values
    char	2 bytes	Stores a single character/letter or ASCII values

 */

public class PrimitiveDataTypes {
    public static void main(String[] args) {
//     1. byte, short, int, long, float, double
//        byte myByteSmallest = -128;
//        byte byteSmallest = Byte.MIN_VALUE;
//        byte myByteLargest = 127;
//        byte byteLargest = Byte.MAX_VALUE;
//        System.out.println(myByteSmallest);
//        System.out.println(myByteLargest);
//
//        short myShortSmallest = -32768;
//        short myShortLargest = 32767;
//        System.out.println(myShortSmallest);
//        System.out.println(myShortLargest);
//
//        int myIntSmallest = -2147483648;
//        int myIntLargest = 2147483647;
//        System.out.println(myIntSmallest);
//        System.out.println(myIntLargest);
//
//        long myLongSmallest = -9223372036854775808L;
//        long myLongLargest = 9223372036854775807L;
//        System.out.println(myLongSmallest);
//        System.out.println(myLongLargest);
//
//        float myFloat = 12345678.123456789f;
//        float floatMin = Float.MIN_VALUE;
//        float myFloat1 = 123456789.12F;
//        float myFloat2 = 12.123456789f;
//        System.out.println(myFloat);
//        System.out.println(myFloat1);
//        System.out.println(myFloat2);
//
//        double myDouble = 7976931348623157.1308;
//        double doubleMax = Double.MAX_VALUE;
//        double myDouble1 = 23456.12345678901234567890123;
//        System.out.println(myDouble);
//        System.out.println(myDouble1);
//        System.out.println(doubleMax);
//
//        boolean myBoolean = true;



        char myVar1 = 75, myVar2 = 65, myVar3 = 84,myVar4 = 89,myVar5 = 65;
        System.out.print(myVar1);
        System.out.print(myVar2);
        System.out.print(myVar3);
        System.out.print(myVar4);
        System.out.print(myVar5);

    }
}
