package day_2;

public class Bus {
}
