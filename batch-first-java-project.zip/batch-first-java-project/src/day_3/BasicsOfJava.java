package day_3;

public class BasicsOfJava {
    public static void main(String[] args) {
        System.out.println("Hello");
        System.out.print("World");
        System.out.println("!!!!!");
        System.out.println("    d    ");
        System.out.println("\tHello and welcome to Java 101. \nHere you will learn how to program in Java. \nWe will use Java 11 and Intellij IDEA. \nHope you have fun here!!! \nIf you have any questions, do not hesitate to ask. \nHave a great rest of your evening. \nThank you.");
        System.out.println("He said he can't \"help\" me.");
        System.out.println("\tHello and welcome!My name is Dmitriy, and I here \nto learn Java Programming so I can be a great automation \nengineer. Our classes are 4 times a week from 7 to 10.\n\nMy instructor said:\"Repitition is key to my successful\ntrasition to I.T\"");
        System.out.println("19");
        System.out.println(19+2);
        System.out.println(5+3+"100");
        System.out.println("100"+5+3);
        System.out.println("abc"+(5+4/2));
        System.out.println("abc"+5+4/2);
    }

}


















































